package phamminhhieu.tuan03_bai1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tuan03Bai1Application {

    public static void main(String[] args) {
        SpringApplication.run(Tuan03Bai1Application.class, args);
    }

}
