package phamminhhieu.buoi03_validation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Buoi03ValidationApplicationTests {

    @Test
    void contextLoads() {
    }

}
