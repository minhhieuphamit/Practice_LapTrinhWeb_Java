package phamminhhieu.buoi03_validation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Buoi03ValidationApplication {

    public static void main(String[] args) {
        SpringApplication.run(Buoi03ValidationApplication.class, args);
    }

}
